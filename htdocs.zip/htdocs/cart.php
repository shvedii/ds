<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

// Инициализация переменных
$error = '';
$success = '';
$total = 0; // Инициализируем переменную total

// Удаление из корзины
if (isset($_GET['remove'])) {
    $dish_id = (int)$_GET['remove'];
    if (isset($_SESSION['cart'][$dish_id])) {
        unset($_SESSION['cart'][$dish_id]);
        $success = 'Блюдо удалено из корзины';
    }
}

// Обновление количества
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_cart'])) {
    foreach ($_POST['quantity'] as $dish_id => $quantity) {
        $dish_id = (int)$dish_id;
        $quantity = (int)$quantity;
        
        if (isset($_SESSION['cart'][$dish_id])) {
            if ($quantity > 0) {
                $_SESSION['cart'][$dish_id]['quantity'] = $quantity;
            } else {
                unset($_SESSION['cart'][$dish_id]);
            }
        }
    }
    $success = 'Корзина обновлена';
}

// Расчет общей суммы
if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total += $item['price'] * $item['quantity'];
    }
}

// Получение информации о бонусах пользователя
$user = getUserById($_SESSION['user_id']);
$bonuses = $user['bonuses'];
$max_bonuses_to_use = min($bonuses, floor($total * 0.5)); // Максимум 50% от суммы заказа
?>

<?php include 'includes/header.php'; ?>

<h1 class="text-center mb-4">Корзина</h1>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success"><?= $success ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-8">
        <?php if (empty($_SESSION['cart'])): ?>
            <div class="alert alert-info">Ваша корзина пуста</div>
            <a href="menu.php" class="btn btn-primary">Вернуться в меню</a>
        <?php else: ?>
            <form method="POST" action="cart.php">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Блюдо</th>
                            <th>Цена</th>
                            <th>Количество</th>
                            <th>Итого</th>
                            <th>Действие</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total = 0;
                        foreach ($_SESSION['cart'] as $item):
                            $subtotal = $item['price'] * $item['quantity'];
                            $total += $subtotal;
                        ?>
                            <tr>
                                <td>
                                    <img src="<?= htmlspecialchars($item['image']) ?>" width="50" height="50" class="me-2">
                                    <?= htmlspecialchars($item['name']) ?>
                                </td>
                                <td><?= $item['price'] ?> руб.</td>
                                <td>
                                    <input type="number" name="quantity[<?= $item['id'] ?>]" value="<?= $item['quantity'] ?>" min="1" class="form-control" style="width: 70px;">
                                </td>
                                <td><?= $subtotal ?> руб.</td>
                                <td>
                                    <a href="cart.php?remove=<?= $item['id'] ?>" class="btn btn-danger btn-sm">Удалить</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-end"><strong>Итого:</strong></td>
                            <td><strong><?= $total ?> руб.</strong></td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
                <div class="d-flex justify-content-between">
                    <a href="menu.php" class="btn btn-secondary">Продолжить покупки</a>
                    <button type="submit" name="update_cart" class="btn btn-warning">Обновить корзину</button>
                    <a href="checkout.php" class="btn btn-primary">Оформить заказ</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Ваши бонусы</h5>
            </div>
            <div class="card-body">
                <p>У вас есть <strong><?= $bonuses ?></strong> бонусов</p>
                <p>Вы можете использовать до <strong><?= $max_bonuses_to_use ?></strong> бонусов (максимум 50% от суммы заказа)</p>
                <p>После оплаты вы получите <strong><?= floor($total * 0.05) ?></strong> бонусов (5% от суммы заказа)</p>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>