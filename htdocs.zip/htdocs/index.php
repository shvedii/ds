<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';
?>

<?php include 'includes/header.php'; ?>

<div class="hero-section text-center py-5 bg-light">
    <h1 class="display-4">Добро пожаловать в AMOUR</h1>
    <p class="lead">Доставка изысканных блюд прямо к вашему столу</p>
    <a href="menu.php" class="btn btn-primary btn-lg mt-3">Посмотреть меню</a>
</div>

<div class="featured-categories mt-5">
    <h2 class="text-center mb-4">Популярные категории</h2>
    <div class="row">
        <?php 
        $categories = getCategories();
        foreach (array_slice($categories, 0, 3) as $category): 
        ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <h3><?= htmlspecialchars($category['categoryName']) ?></h3>
                        <a href="menu.php?category=<?= $category['id'] ?>" class="btn btn-outline-primary">Смотреть</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="testimonials mt-5 bg-light py-5">
    <h2 class="text-center mb-4">Отзывы наших клиентов</h2>
    <div class="row">
        <?php 
        $reviews = getReviews();
        foreach (array_slice($reviews, 0, 3) as $review): 
        ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($review['nameOfAccount']) ?></h5>
                        <div class="rating mb-2">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <span class="fa fa-star<?= $i <= $review['rating'] ? ' checked' : '' ?>"></span>
                            <?php endfor; ?>
                        </div>
                        <p class="card-text"><?= htmlspecialchars($review['textReview']) ?></p>
                        <small class="text-muted"><?= $review['createdAtReview'] ?></small>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="text-center mt-3">
        <a href="reviews.php" class="btn btn-primary">Все отзывы</a>
    </div>
</div>

<?php include 'includes/footer.php'; ?>