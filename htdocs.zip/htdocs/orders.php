<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

// Получение заказов пользователя
$stmt = $conn->prepare("
    SELECT o.*, a.nameOfAccount as courierName 
    FROM Orders o 
    LEFT JOIN Account a ON o.courierId = a.id 
    WHERE o.clientId = ? 
    ORDER BY o.createdAtOrder DESC
");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<?php include 'includes/header.php'; ?>

<h1 class="text-center mb-4">Мои заказы</h1>

<?php if (empty($orders)): ?>
    <div class="alert alert-info">У вас пока нет заказов</div>
    <div class="text-center">
        <a href="menu.php" class="btn btn-primary">Перейти в меню</a>
    </div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>№ заказа</th>
                    <th>Дата</th>
                    <th>Адрес</th>
                    <th>Статус</th>
                    <th>Сумма</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?= $order['id'] ?></td>
                        <td><?= date('d.m.Y H:i', strtotime($order['createdAtOrder'])) ?></td>
                        <td><?= htmlspecialchars($order['address']) ?></td>
                        <td>
                            <span class="badge 
                                <?= $order['status'] == 'Доставлен' ? 'bg-success' : '' ?>
                                <?= $order['status'] == 'Отменен' ? 'bg-danger' : '' ?>
                                <?= in_array($order['status'], ['В ожидании', 'Принят', 'Готов', 'В пути']) ? 'bg-warning' : '' ?>
                            ">
                                <?= $order['status'] ?>
                            </span>
                        </td>
                        <td><?= $order['totalPrice'] ?> руб.</td>
                        <td>
                            <a href="order_details.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-primary">Подробнее</a>
                            <?php if ($order['status'] == 'В ожидании'): ?>
                                <a href="cancel_order.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Вы уверены, что хотите отменить заказ?')">Отменить</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>