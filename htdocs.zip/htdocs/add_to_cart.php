<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['dish_id'])) {
    $dish_id = (int)$_POST['dish_id'];
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    
    // Получаем информацию о блюде
    $dish = getDishById($dish_id);
    
    if ($dish) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        
        if (isset($_SESSION['cart'][$dish_id])) {
            $_SESSION['cart'][$dish_id]['quantity'] += $quantity;
        } else {
            $_SESSION['cart'][$dish_id] = [
                'id' => $dish_id,
                'name' => $dish['nameOfDish'],
                'price' => $dish['price'],
                'quantity' => $quantity,
                'image' => $dish['imagePath']
            ];
        }
        
        header("Location: cart.php");
        exit();
    }
}

header("Location: menu.php");
exit();
?>