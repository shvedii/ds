<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

$error = '';
$success = '';

// Добавление отзыва
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isLoggedIn()) {
    $text = trim($_POST['text']);
    $rating = (int)$_POST['rating'];
    
    if (empty($text)) {
        $error = 'Текст отзыва не может быть пустым';
    } elseif ($rating < 1 || $rating > 5) {
        $error = 'Рейтинг должен быть от 1 до 5';
    } else {
        $stmt = $conn->prepare("INSERT INTO Review (textReview, createdAtReview, rating, clientId) VALUES (?, CURDATE(), ?, ?)");
        $stmt->bind_param("sii", $text, $rating, $_SESSION['user_id']);
        
        if ($stmt->execute()) {
            $success = 'Ваш отзыв успешно добавлен';
        } else {
            $error = 'Ошибка при добавлении отзыва: ' . $conn->error;
        }
    }
}

$reviews = getReviews();
?>

<?php include 'includes/header.php'; ?>

<h1 class="text-center mb-4">Отзывы о нашем ресторане</h1>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success"><?= $success ?></div>
<?php endif; ?>

<?php if (isLoggedIn()): ?>
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title">Оставить отзыв</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="reviews.php">
                <div class="mb-3">
                    <label for="text" class="form-label">Ваш отзыв</label>
                    <textarea class="form-control" id="text" name="text" rows="3" required></textarea>
                </div>
                <div class="mb-3">
                    <label for="rating" class="form-label">Оценка</label>
                    <select class="form-select" id="rating" name="rating" required>
                        <option value="5">Отлично (5)</option>
                        <option value="4">Хорошо (4)</option>
                        <option value="3">Удовлетворительно (3)</option>
                        <option value="2">Плохо (2)</option>
                        <option value="1">Ужасно (1)</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Отправить отзыв</button>
            </form>
        </div>
    </div>
<?php else: ?>
    <div class="alert alert-info">Чтобы оставить отзыв, пожалуйста, <a href="login.php">войдите</a> или <a href="register.php">зарегистрируйтесь</a>.</div>
<?php endif; ?>

<div class="reviews-list">
    <?php foreach ($reviews as $review): ?>
        <div class="card mb-3">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h5 class="card-title"><?= htmlspecialchars($review['nameOfAccount']) ?></h5>
                    <div class="rating">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <span class="fa fa-star<?= $i <= $review['rating'] ? ' checked' : '' ?>"></span>
                        <?php endfor; ?>
                    </div>
                </div>
                <p class="card-text"><?= htmlspecialchars($review['textReview']) ?></p>
                <small class="text-muted"><?= $review['createdAtReview'] ?></small>
                
                <?php 
                $responses = getResponsesForReview($review['id']);
                foreach ($responses as $response): 
                ?>
                    <div class="card mt-3 bg-light">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h6 class="card-subtitle mb-2 text-muted">Ответ администрации</h6>
                                <small class="text-muted"><?= $response['createdAtResponse'] ?></small>
                            </div>
                            <p class="card-text"><?= htmlspecialchars($response['responseText']) ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php include 'includes/footer.php'; ?>