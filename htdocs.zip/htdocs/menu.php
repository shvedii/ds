<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

$selectedCategory = isset($_GET['category']) ? (int)$_GET['category'] : null;
$categories = getCategories();
?>

<?php include 'includes/header.php'; ?>

<h1 class="text-center mb-4">Наше меню</h1>

<div class="row">
    <div class="col-md-3">
        <div class="list-group">
            <a href="menu.php" class="list-group-item list-group-item-action<?= !$selectedCategory ? ' active' : '' ?>">Все категории</a>
            <?php foreach ($categories as $category): ?>
                <a href="menu.php?category=<?= $category['id'] ?>" class="list-group-item list-group-item-action<?= $selectedCategory == $category['id'] ? ' active' : '' ?>">
                    <?= htmlspecialchars($category['categoryName']) ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="col-md-9">
        <div class="row">
            <?php
            if ($selectedCategory) {
                $dishes = getDishesByCategory($selectedCategory);
            } else {
                $sql = "SELECT * FROM Dish";
                $result = $conn->query($sql);
                $dishes = $result->fetch_all(MYSQLI_ASSOC);
            }
            
            foreach ($dishes as $dish):
            ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <img src="<?= htmlspecialchars($dish['imagePath']) ?>" class="card-img-top" alt="<?= htmlspecialchars($dish['nameOfDish']) ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($dish['nameOfDish']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($dish['descriptionOfDishes']) ?></p>
                            <p class="card-text"><strong><?= $dish['price'] ?> руб.</strong></p>
                            <?php if (isLoggedIn()): ?>
                                <form method="POST" action="add_to_cart.php">
                                    <input type="hidden" name="dish_id" value="<?= $dish['id'] ?>">
                                    <div class="input-group mb-3">
                                        <input type="number" name="quantity" class="form-control" value="1" min="1">
                                        <button class="btn btn-primary" type="submit">В корзину</button>
                                    </div>
                                </form>
                            <?php else: ?>
                                <a href="login.php" class="btn btn-primary">Войдите, чтобы заказать</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>