<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

// Инициализация переменных для сообщений
$error = '';
$success = '';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if (empty($_SESSION['cart'])) {
    header("Location: cart.php");
    exit();
}

// Получение информации о пользователе
$user = getUserById($_SESSION['user_id']);
$bonuses = $user['bonuses'];

// Расчет общей суммы
$total = 0;
foreach ($_SESSION['cart'] as $item) {
    $total += $item['price'] * $item['quantity'];
}

// Максимальное количество бонусов для списания (50% от суммы заказа)
$max_bonuses_to_use = min($bonuses, floor($total * 0.5));

// Минимальное количество бонусов для списания
$min_bonuses_to_use = 1;

// Обработка оформления заказа
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone']);
    $paymentType = trim($_POST['paymentType']);
    $comments = trim($_POST['comments']);
    $useBonuses = isset($_POST['use_bonuses']) ? (int)$_POST['bonuses_amount'] : 0;
    
    // Валидация
    if (empty($address) || empty($phone)) {
        $error = 'Адрес и телефон обязательны для заполнения';
    } elseif ($useBonuses > 0 && $useBonuses < $min_bonuses_to_use) {
        $error = 'Минимальное количество бонусов для списания: '.$min_bonuses_to_use;
    } elseif ($useBonuses > $max_bonuses_to_use) {
        $error = 'Нельзя использовать больше бонусов, чем разрешено (максимум '.$max_bonuses_to_use.' бонусов)';
    } else {
        // Расчет итоговой суммы с учетом бонусов
        $finalPrice = max($total - $useBonuses, 0); // Не может быть меньше 0
        
        // Создание заказа
        $conn->begin_transaction();
        
        try {
            // Вставка заказа
            $stmt = $conn->prepare("INSERT INTO Orders (address, phone, paymentType, comments, totalPrice, usedBonuses, clientId) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $usedBonusesBool = $useBonuses > 0 ? 1 : 0;
            $stmt->bind_param("ssssiii", $address, $phone, $paymentType, $comments, $finalPrice, $usedBonusesBool, $_SESSION['user_id']);
            $stmt->execute();
            $orderId = $conn->insert_id;
            
            // Вставка блюд заказа
            foreach ($_SESSION['cart'] as $item) {
                $stmt = $conn->prepare("INSERT INTO OrderOfDish (quantity, priceDish, dishId, orderId) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("iiii", $item['quantity'], $item['price'], $item['id'], $orderId);
                $stmt->execute();
            }
            
            // Списание бонусов, если они использовались
            if ($useBonuses > 0) {
                $newBonuses = $bonuses - $useBonuses;
                $stmt = $conn->prepare("UPDATE Account SET bonuses = ? WHERE id = ?");
                $stmt->bind_param("ii", $newBonuses, $_SESSION['user_id']);
                $stmt->execute();
            }
            
            // Начисление бонусов (5% от суммы заказа)
            $earnedBonuses = floor($finalPrice * 0.05);
            if ($earnedBonuses > 0) {
                $newBonuses = ($useBonuses > 0 ? $bonuses - $useBonuses : $bonuses) + $earnedBonuses;
                $stmt = $conn->prepare("UPDATE Account SET bonuses = ? WHERE id = ?");
                $stmt->bind_param("ii", $newBonuses, $_SESSION['user_id']);
                $stmt->execute();
            }
            
            $conn->commit();
            
            // Очистка корзины
            unset($_SESSION['cart']);
            
            $success = "Заказ #$orderId успешно оформлен! Начислено $earnedBonuses бонусов. Спасибо за покупку.";
            header("refresh:3; url=orders.php");
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Ошибка при оформлении заказа: " . $e->getMessage();
        }
    }
}
?>

<?php include 'includes/header.php'; ?>

<h1 class="text-center mb-4">Оформление заказа</h1>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if (!empty($success)): ?>
    <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
<?php else: ?>
    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title">Детали заказа</h5>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Блюдо</th>
                                <th>Цена</th>
                                <th>Количество</th>
                                <th>Итого</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $total = 0;
                            foreach ($_SESSION['cart'] as $item):
                                $subtotal = $item['price'] * $item['quantity'];
                                $total += $subtotal;
                            ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['name']) ?></td>
                                    <td><?= $item['price'] ?> руб.</td>
                                    <td><?= $item['quantity'] ?></td>
                                    <td><?= $subtotal ?> руб.</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3" class="text-end"><strong>Итого:</strong></td>
                                <td><strong><?= $total ?> руб.</strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">Данные для доставки</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="checkout.php">
                        <div class="mb-3">
                            <label for="address" class="form-label">Адрес доставки</label>
                            <input type="text" class="form-control" id="address" name="address" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Телефон</label>
                            <input type="tel" class="form-control" id="phone" name="phone" required>
                        </div>
                        <div class="mb-3">
                            <label for="paymentType" class="form-label">Способ оплаты</label>
                            <select class="form-select" id="paymentType" name="paymentType" required>
                                <option value="Карта">Карта</option>
                                <option value="Электронный кошелек">Электронный кошелек</option>
                                <option value="СПБ">СПБ</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="comments" class="form-label">Комментарии к заказу</label>
                            <textarea class="form-control" id="comments" name="comments" rows="3"></textarea>
                        </div>
                        
                        <?php if ($max_bonuses_to_use > 0): ?>
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="use_bonuses" name="use_bonuses" onchange="toggleBonuses()">
                                <label class="form-check-label" for="use_bonuses">Использовать бонусы</label>
                            </div>
                            <div class="mb-3" id="bonuses_field" style="display: none;">
                                <label for="bonuses_amount" class="form-label">Количество бонусов (от <?= $min_bonuses_to_use ?> до <?= $max_bonuses_to_use ?>)</label>
                                <input type="number" class="form-control" id="bonuses_amount" name="bonuses_amount" 
                                min="<?= $min_bonuses_to_use ?>" max="<?= $max_bonuses_to_use ?>" 
                                value="<?= min($max_bonuses_to_use, max($min_bonuses_to_use, $bonuses)) ?>">
                            </div>
                        <?php endif; ?>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary btn-lg">Подтвердить заказ</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">Итоговая сумма</h5>
                </div>
                <div class="card-body">
                    <p>Товаров на сумму: <strong><?= $total ?> руб.</strong></p>
                    <?php if ($max_bonuses_to_use > 0): ?>
                        <p>Бонусов к списанию: <span id="bonuses_used">0</span> руб.</p>
                        <p>Итого к оплате: <strong><span id="final_price"><?= $total ?></span> руб.</strong></p>
                        <p class="text-muted">После оплаты вы получите <span id="earned_bonuses"><?= floor($total * 0.05) ?></span> бонусов (5% от суммы)</p>
                    <?php else: ?>
                        <p>Итого к оплате: <strong><?= $total ?> руб.</strong></p>
                        <p class="text-muted">После оплаты вы получите <?= floor($total * 0.05) ?> бонусов (5% от суммы)</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function toggleBonuses() {
            const bonusesField = document.getElementById('bonuses_field');
            const useBonuses = document.getElementById('use_bonuses');
            
            if (useBonuses.checked) {
                bonusesField.style.display = 'block';
                updateFinalPrice();
            } else {
                bonusesField.style.display = 'none';
                document.getElementById('bonuses_used').textContent = '0';
                document.getElementById('final_price').textContent = '<?= $total ?>';
                document.getElementById('earned_bonuses').textContent = '<?= floor($total * 0.05) ?>';
            }
        }
        
        function updateFinalPrice() {
            const total = <?= $total ?>;
            let bonusesAmount = parseInt(document.getElementById('bonuses_amount').value) || 0;
            const maxBonuses = <?= $max_bonuses_to_use ?>;
            const minBonuses = <?= $min_bonuses_to_use ?>;
        
        // Проверка минимального и максимального количества
        if (bonusesAmount < minBonuses) {
            bonusesAmount = minBonuses;
            document.getElementById('bonuses_amount').value = minBonuses;
        } else if (bonusesAmount > maxBonuses) {
            bonusesAmount = maxBonuses;
            document.getElementById('bonuses_amount').value = maxBonuses;
        }
        
        const finalPrice = Math.max(total - bonusesAmount, 0);
        const earnedBonuses = Math.floor(finalPrice * 0.05);
        
        document.getElementById('bonuses_used').textContent = bonusesAmount;
        document.getElementById('final_price').textContent = finalPrice;
        document.getElementById('earned_bonuses').textContent = earnedBonuses;
    }
    </script>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>