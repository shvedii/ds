<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

redirectIfNotCourier();

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$orderId = (int)$_GET['id'];

// Проверяем, что заказ назначен текущему курьеру и находится в пути
$stmt = $conn->prepare("SELECT id FROM Orders WHERE id = ? AND status = 'В пути' AND courierId = ?");
$stmt->bind_param("ii", $orderId, $_SESSION['user_id']);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header("Location: dashboard.php?error=Заказ недоступен для завершения");
    exit();
}

// Завершаем заказ
$stmt = $conn->prepare("UPDATE Orders SET status = 'Доставлен' WHERE id = ?");
$stmt->bind_param("i", $orderId);

if ($stmt->execute()) {
    header("Location: dashboard.php?success=Заказ успешно завершен");
} else {
    header("Location: dashboard.php?error=Ошибка при завершении заказа");
}
exit();
?>