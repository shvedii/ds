<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

redirectIfNotCourier();

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$orderId = (int)$_GET['id'];

// Проверяем, что заказ доступен для принятия
$stmt = $conn->prepare("SELECT id FROM Orders WHERE id = ? AND status = 'Готов' AND courierId IS NULL");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header("Location: dashboard.php?error=Заказ недоступен для принятия");
    exit();
}

// Назначаем заказ текущему курьеру
$stmt = $conn->prepare("UPDATE Orders SET status = 'В пути', courierId = ? WHERE id = ?");
$stmt->bind_param("ii", $_SESSION['user_id'], $orderId);

if ($stmt->execute()) {
    header("Location: dashboard.php?success=Заказ успешно принят");
} else {
    header("Location: dashboard.php?error=Ошибка при принятии заказа");
}
exit();
?>