<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

redirectIfNotCourier();

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$orderId = (int)$_GET['id'];

// Получение информации о заказе
$stmt = $conn->prepare("
    SELECT o.*, a.nameOfAccount as clientName 
    FROM Orders o 
    JOIN Account a ON o.clientId = a.id 
    WHERE o.id = ? AND (o.courierId = ? OR o.status = 'Готов')
");
$stmt->bind_param("ii", $orderId, $_SESSION['user_id']);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header("Location: dashboard.php?error=Заказ не найден");
    exit();
}

// Получение блюд заказа
$stmt = $conn->prepare("
    SELECT od.*, d.nameOfDish, d.imagePath 
    FROM OrderOfDish od 
    JOIN Dish d ON od.dishId = d.id 
    WHERE od.orderId = ?
");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$dishes = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<?php include '../includes/header.php'; ?>

<h1 class="text-center mb-4">Заказ #<?= $order['id'] ?></h1>

<div class="row">
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Информация о заказе</h5>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label">Статус</label>
                    <input type="text" class="form-control" value="<?= $order['status'] ?>" readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label">Клиент</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($order['clientName']) ?>" readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label">Адрес</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($order['address']) ?>" readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label">Телефон</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($order['phone']) ?>" readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label">Комментарии</label>
                    <textarea class="form-control" readonly><?= htmlspecialchars($order['comments']) ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Дата заказа</label>
                    <input type="text" class="form-control" value="<?= date('d.m.Y H:i', strtotime($order['createdAtOrder'])) ?>" readonly>
                </div>
                
                <?php if ($order['status'] == 'Готов' && $order['courierId'] === null): ?>
                    <a href="take_order.php?id=<?= $order['id'] ?>" class="btn btn-primary">Принять заказ</a>
                <?php elseif ($order['status'] == 'В пути' && $order['courierId'] == $_SESSION['user_id']): ?>
                    <a href="complete_order.php?id=<?= $order['id'] ?>" class="btn btn-success">Заказ доставлен</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Состав заказа</h5>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Блюдо</th>
                            <th>Количество</th>
                            <th>Цена</th>
                            <th>Итого</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dishes as $dish): ?>
                            <tr>
                                <td>
                                    <img src="../<?= htmlspecialchars($dish['imagePath']) ?>" width="50" height="50" class="me-2">
                                    <?= htmlspecialchars($dish['nameOfDish']) ?>
                                </td>
                                <td><?= $dish['quantity'] ?></td>
                                <td><?= $dish['priceDish'] ?> руб.</td>
                                <td><?= $dish['priceDish'] * $dish['quantity'] ?> руб.</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-end"><strong>Итого:</strong></td>
                            <td><strong><?= $order['totalPrice'] ?> руб.</strong></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="text-center">
    <a href="dashboard.php" class="btn btn-secondary">Вернуться в панель</a>
</div>

<?php include '../includes/footer.php'; ?>