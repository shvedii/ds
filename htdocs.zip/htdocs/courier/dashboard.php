<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

redirectIfNotCourier();

// Получение назначенных заказов
$stmt = $conn->prepare("
    SELECT o.*, a.nameOfAccount as clientName 
    FROM Orders o 
    JOIN Account a ON o.clientId = a.id 
    WHERE o.courierId = ? AND o.status IN ('В пути', 'Готов')
    ORDER BY o.createdAtOrder DESC
");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$assignedOrders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Получение доступных для принятия заказов
$availableOrders = $conn->query("
    SELECT o.*, a.nameOfAccount as clientName 
    FROM Orders o 
    JOIN Account a ON o.clientId = a.id 
    WHERE o.status = 'Готов' AND o.courierId IS NULL
    ORDER BY o.createdAtOrder DESC
")->fetch_all(MYSQLI_ASSOC);
?>

<?php include '../includes/header.php'; ?>

<h1 class="text-center mb-4">Панель курьера</h1>

<div class="row">
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Мои заказы</h5>
            </div>
            <div class="card-body">
                <?php if (empty($assignedOrders)): ?>
                    <div class="alert alert-info">У вас нет назначенных заказов</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>№</th>
                                    <th>Клиент</th>
                                    <th>Адрес</th>
                                    <th>Статус</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($assignedOrders as $order): ?>
                                    <tr>
                                        <td><?= $order['id'] ?></td>
                                        <td><?= htmlspecialchars($order['clientName']) ?></td>
                                        <td><?= htmlspecialchars($order['address']) ?></td>
                                        <td>
                                            <span class="badge 
                                                <?= $order['status'] == 'В пути' ? 'bg-warning' : 'bg-info' ?>
                                            ">
                                                <?= $order['status'] ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="order.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-primary">Подробнее</a>
                                            <?php if ($order['status'] == 'В пути'): ?>
                                                <a href="complete_order.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-success">Доставлен</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Доступные заказы</h5>
            </div>
            <div class="card-body">
                <?php if (empty($availableOrders)): ?>
                    <div class="alert alert-info">Нет доступных заказов</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>№</th>
                                    <th>Клиент</th>
                                    <th>Адрес</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($availableOrders as $order): ?>
                                    <tr>
                                        <td><?= $order['id'] ?></td>
                                        <td><?= htmlspecialchars($order['clientName']) ?></td>
                                        <td><?= htmlspecialchars($order['address']) ?></td>
                                        <td>
                                            <a href="take_order.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-primary">Принять заказ</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>