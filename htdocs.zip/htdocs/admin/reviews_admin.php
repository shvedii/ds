<?php
require_once '../includes/admin/header.php';

// Получение отзывов с ответами
$reviews = $conn->query("
    SELECT r.*, a.nameOfAccount, ad.nameOfAccount as adminName, res.responseText, res.createdAtResponse
    FROM Review r
    JOIN Account a ON r.clientId = a.id
    LEFT JOIN Response res ON res.reviewId = r.id
    LEFT JOIN Account ad ON res.adminId = ad.id
    ORDER BY r.createdAtReview DESC
")->fetch_all(MYSQLI_ASSOC);

// Обработка добавления ответа
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['review_id'])) {
    $reviewId = (int)$_POST['review_id'];
    $responseText = trim($_POST['response']);
    
    if (!empty($responseText)) {
        $stmt = $conn->prepare("INSERT INTO Response (responseText, createdAtResponse, adminId, reviewId) VALUES (?, NOW(), ?, ?)");
        $stmt->bind_param("sii", $responseText, $_SESSION['user_id'], $reviewId);
        
        if ($stmt->execute()) {
            header("Location: reviews_admin.php?success=Ответ добавлен");
            exit();
        }
    }
}
?>

<h2><i class="bi bi-chat-left-text"></i> Управление отзывами</h2>

<?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success"><?= htmlspecialchars($_GET['success']) ?></div>
<?php endif; ?>

<div class="card mt-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Пользователь</th>
                        <th>Оценка</th>
                        <th>Отзыв</th>
                        <th>Дата</th>
                        <th>Ответ</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reviews as $review): ?>
                    <tr>
                        <td><?= htmlspecialchars($review['nameOfAccount']) ?></td>
                        <td>
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="bi bi-star<?= $i <= $review['rating'] ? '-fill text-warning' : '' ?>"></i>
                            <?php endfor; ?>
                        </td>
                        <td><?= htmlspecialchars($review['textReview']) ?></td>
                        <td><?= date('d.m.Y', strtotime($review['createdAtReview'])) ?></td>
                        <td>
                            <?php if (!empty($review['responseText'])): ?>
                                <strong><?= htmlspecialchars($review['adminName']) ?>:</strong>
                                <?= htmlspecialchars($review['responseText']) ?>
                                <div class="text-muted small">
                                    <?= date('d.m.Y', strtotime($review['createdAtResponse'])) ?>
                                </div>
                            <?php else: ?>
                                <span class="text-danger">Нет ответа</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (empty($review['responseText'])): ?>
                                <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#responseModal<?= $review['id'] ?>">
                                    Ответить
                                </button>
                                
                                <!-- Модальное окно для ответа -->
                                <div class="modal fade" id="responseModal<?= $review['id'] ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Ответ на отзыв</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <form method="POST" action="reviews_admin.php">
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label class="form-label">Отзыв:</label>
                                                        <p><?= htmlspecialchars($review['textReview']) ?></p>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="response<?= $review['id'] ?>" class="form-label">Ваш ответ:</label>
                                                        <textarea class="form-control" id="response<?= $review['id'] ?>" name="response" rows="3" required></textarea>
                                                    </div>
                                                    <input type="hidden" name="review_id" value="<?= $review['id'] ?>">
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                                                    <button type="submit" class="btn btn-primary">Отправить</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <button class="btn btn-sm btn-outline-secondary" disabled>Отвечено</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/admin/footer.php'; ?>