<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

redirectIfNotAdmin();

// Статистика
$usersCount = $conn->query("SELECT COUNT(*) FROM Account")->fetch_row()[0];
$ordersCount = $conn->query("SELECT COUNT(*) FROM Orders")->fetch_row()[0];
$revenue = $conn->query("SELECT SUM(totalPrice) FROM Orders WHERE status = 'Доставлен'")->fetch_row()[0];
$pendingOrders = $conn->query("SELECT COUNT(*) FROM Orders WHERE status = 'В ожидании'")->fetch_row()[0];

// Последние заказы
$latestOrders = $conn->query("
    SELECT o.*, a.nameOfAccount as clientName 
    FROM Orders o 
    JOIN Account a ON o.clientId = a.id 
    ORDER BY o.createdAtOrder DESC 
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);

// Последние отзывы
$latestReviews = $conn->query("
    SELECT r.*, a.nameOfAccount 
    FROM Review r 
    JOIN Account a ON r.clientId = a.id 
    ORDER BY r.createdAtReview DESC 
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);
?>

<?php include '../includes/admin/header.php'; ?>

<h1 class="text-center mb-4">Административная панель</h1>

<div class="row mb-4">
    <div class="col-md-3">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <h5 class="card-title">Пользователи</h5>
                <p class="card-text display-4"><?= $usersCount ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-success">
            <div class="card-body">
                <h5 class="card-title">Заказы</h5>
                <p class="card-text display-4"><?= $ordersCount ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-info">
            <div class="card-body">
                <h5 class="card-title">Выручка</h5>
                <p class="card-text display-4"><?= $revenue ? $revenue : '0' ?> руб.</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <h5 class="card-title">Ожидают</h5>
                <p class="card-text display-4"><?= $pendingOrders ?></p>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Последние заказы</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>№</th>
                                <th>Клиент</th>
                                <th>Сумма</th>
                                <th>Статус</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($latestOrders as $order): ?>
                                <tr>
                                    <td><a href="order.php?id=<?= $order['id'] ?>"><?= $order['id'] ?></a></td>
                                    <td><?= htmlspecialchars($order['clientName']) ?></td>
                                    <td><?= $order['totalPrice'] ?> руб.</td>
                                    <td>
                                        <span class="badge 
                                            <?= $order['status'] == 'Доставлен' ? 'bg-success' : '' ?>
                                            <?= $order['status'] == 'Отменен' ? 'bg-danger' : '' ?>
                                            <?= in_array($order['status'], ['В ожидании', 'Принят', 'Готов', 'В пути']) ? 'bg-warning' : '' ?>
                                        ">
                                            <?= $order['status'] ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <a href="orders.php" class="btn btn-primary">Все заказы</a>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Последние отзывы</h5>
            </div>
            <div class="card-body">
                <div class="reviews-list">
                    <?php foreach ($latestReviews as $review): ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between">
                                <h6><?= htmlspecialchars($review['nameOfAccount']) ?></h6>
                                <div class="rating">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <span class="fa fa-star<?= $i <= $review['rating'] ? ' checked' : '' ?>"></span>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <p><?= htmlspecialchars($review['textReview']) ?></p>
                            <small class="text-muted"><?= $review['createdAtReview'] ?></small>
                        </div>
                        <hr>
                    <?php endforeach; ?>
                </div>
                <a href="reviews_admin.php" class="btn btn-primary">Все отзывы</a>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/admin/footer.php'; ?>