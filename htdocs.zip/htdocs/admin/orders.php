<?php
require_once '../includes/admin/header.php';

$orders = $conn->query("
    SELECT o.*, a.nameOfAccount as clientName, c.nameOfAccount as courierName 
    FROM Orders o 
    JOIN Account a ON o.clientId = a.id 
    LEFT JOIN Account c ON o.courierId = c.id 
    ORDER BY o.createdAtOrder DESC
")->fetch_all(MYSQLI_ASSOC);
?>

<h2><i class="bi bi-cart"></i> Управление заказами</h2>

<table class="table table-striped mt-4">
    <thead>
        <tr>
            <th>ID</th>
            <th>Клиент</th>
            <th>Сумма</th>
            <th>Статус</th>
            <th>Дата</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($orders as $order): ?>
        <tr>
            <td><?= $order['id'] ?></td>
            <td><?= htmlspecialchars($order['clientName']) ?></td>
            <td><?= $order['totalPrice'] ?> руб.</td>
            <td>
                <span class="badge bg-<?= 
                    $order['status'] == 'Доставлен' ? 'success' : 
                    ($order['status'] == 'Отменен' ? 'danger' : 'warning') 
                ?>">
                    <?= $order['status'] ?>
                </span>
            </td>
            <td><?= date('d.m.Y H:i', strtotime($order['createdAtOrder'])) ?></td>
            <td>
                <a href="order_details.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-primary">
                    <i class="bi bi-eye"></i>
                </a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require_once '../includes/admin/footer.php'; ?>