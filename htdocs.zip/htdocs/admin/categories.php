<?php
require_once '../includes/admin/header.php';

// Установка хлебных крошек
$breadcrumbs = [
    ['title' => 'Категории меню', 'link' => '']
];

// Получение списка категорий
$categories = $conn->query("SELECT * FROM Category ORDER BY categoryName")->fetch_all(MYSQLI_ASSOC);

// Обработка удаления категории
if (isset($_GET['delete'])) {
    $categoryId = (int)$_GET['delete'];
    
    // Проверка, есть ли блюда в этой категории
    $stmt = $conn->prepare("SELECT COUNT(*) FROM Dish WHERE categoryId = ?");
    $stmt->bind_param("i", $categoryId);
    $stmt->execute();
    $count = $stmt->get_result()->fetch_row()[0];
    
    if ($count > 0) {
        header("Location: categories.php?error=Невозможно удалить категорию, так как в ней есть блюда");
        exit();
    }
    
    $stmt = $conn->prepare("DELETE FROM Category WHERE id = ?");
    $stmt->bind_param("i", $categoryId);
    
    if ($stmt->execute()) {
        header("Location: categories.php?success=Категория успешно удалена");
        exit();
    }
}
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h4><i class="bi bi-tags"></i> Управление категориями</h4>
        <a href="add_category.php" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Добавить категорию
        </a>
    </div>
    <div class="card-body">
        <?php if (empty($categories)): ?>
            <div class="alert alert-info">Нет доступных категорий</div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped datatable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Название</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories as $category): ?>
                        <tr>
                            <td><?= $category['id'] ?></td>
                            <td><?= htmlspecialchars($category['categoryName']) ?></td>
                            <td>
                                <a href="edit_category.php?id=<?= $category['id'] ?>" class="btn btn-sm btn-warning" title="Редактировать">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <a href="categories.php?delete=<?= $category['id'] ?>" class="btn btn-sm btn-danger delete-btn" title="Удалить">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/admin/footer.php'; ?>