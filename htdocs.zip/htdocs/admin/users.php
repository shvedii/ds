<?php
require_once '../includes/admin/header.php';

// Получение списка пользователей
$users = $conn->query("
    SELECT a.*, r.roleName 
    FROM Account a 
    JOIN Role r ON a.roleId = r.id 
    ORDER BY a.nameOfAccount
")->fetch_all(MYSQLI_ASSOC);
?>

<h2><i class="bi bi-people"></i> Управление пользователями</h2>

<?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success"><?= htmlspecialchars($_GET['success']) ?></div>
<?php endif; ?>

<table class="table table-striped mt-4">
    <thead>
        <tr>
            <th>ID</th>
            <th>Имя</th>
            <th>Email</th>
            <th>Роль</th>
            <th>Бонусы</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?= $user['id'] ?></td>
            <td><?= htmlspecialchars($user['nameOfAccount']) ?></td>
            <td><?= htmlspecialchars($user['email']) ?></td>
            <td><?= htmlspecialchars($user['roleName']) ?></td>
            <td><?= $user['bonuses'] ?></td>
            <td>
                <a href="edit_user.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-warning">
                    <i class="bi bi-pencil"></i>
                </a>
                <a href="delete_user.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Удалить пользователя?')">
                    <i class="bi bi-trash"></i>
                </a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<a href="add_user.php" class="btn btn-primary">
    <i class="bi bi-plus-circle"></i> Добавить пользователя
</a>

<?php require_once '../includes/admin/footer.php'; ?>