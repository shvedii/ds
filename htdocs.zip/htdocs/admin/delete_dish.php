<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

redirectIfNotAdmin();

if (!isset($_GET['id'])) {
    header("Location: dishes.php");
    exit();
}

$dishId = (int)$_GET['id'];

// Проверяем, нет ли этого блюда в заказах
$stmt = $conn->prepare("SELECT COUNT(*) FROM OrderOfDish WHERE dishId = ?");
$stmt->bind_param("i", $dishId);
$stmt->execute();
$count = $stmt->get_result()->fetch_row()[0];

if ($count > 0) {
    header("Location: dishes.php?error=Невозможно удалить блюдо, так как оно есть в заказах");
    exit();
}

// Получаем информацию о блюде для удаления изображения
$stmt = $conn->prepare("SELECT imagePath FROM Dish WHERE id = ?");
$stmt->bind_param("i", $dishId);
$stmt->execute();
$dish = $stmt->get_result()->fetch_assoc();

// Удаляем блюдо
$stmt = $conn->prepare("DELETE FROM Dish WHERE id = ?");
$stmt->bind_param("i", $dishId);

if ($stmt->execute()) {
    // Удаляем изображение, если оно не дефолтное
    if ($dish['imagePath'] != 'assets/images/dishes/default.jpg') {
        @unlink('../' . $dish['imagePath']);
    }
    header("Location: dishes.php?success=Блюдо успешно удалено");
} else {
    header("Location: dishes.php?error=Ошибка при удалении блюда");
}
?>