<?php
require_once '../includes/admin/header.php';

if (!isset($_GET['id'])) {
    header("Location: users.php");
    exit();
}

$userId = (int)$_GET['id'];
$roles = $conn->query("SELECT * FROM Role")->fetch_all(MYSQLI_ASSOC);

// Получение данных пользователя
$stmt = $conn->prepare("SELECT * FROM Account WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    header("Location: users.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $roleId = (int)$_POST['role_id'];
    $bonuses = (int)$_POST['bonuses'];
    
    $stmt = $conn->prepare("UPDATE Account SET nameOfAccount = ?, email = ?, roleId = ?, bonuses = ? WHERE id = ?");
    $stmt->bind_param("ssiii", $name, $email, $roleId, $bonuses, $userId);
    
    if ($stmt->execute()) {
        header("Location: users.php?success=Пользователь успешно обновлен");
        exit();
    }
}
?>

<h2><i class="bi bi-pencil"></i> Редактирование пользователя</h2>

<form method="POST">
    <div class="mb-3">
        <label class="form-label">Имя</label>
        <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($user['nameOfAccount']) ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Роль</label>
        <select class="form-select" name="role_id" required>
            <?php foreach ($roles as $role): ?>
                <option value="<?= $role['id'] ?>" <?= $role['id'] == $user['roleId'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($role['roleName']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Бонусы</label>
        <input type="number" class="form-control" name="bonuses" value="<?= $user['bonuses'] ?>" min="0">
    </div>
    <button type="submit" class="btn btn-primary">Сохранить</button>
    <a href="users.php" class="btn btn-secondary">Отмена</a>
</form>

<?php require_once '../includes/admin/footer.php'; ?>