<?php
require_once '../includes/admin/header.php';

$dishes = $conn->query("
    SELECT d.*, c.categoryName 
    FROM Dish d 
    JOIN Category c ON d.categoryId = c.id 
    ORDER BY d.nameOfDish
")->fetch_all(MYSQLI_ASSOC);
?>

<h2><i class="bi bi-egg-fried"></i> Управление меню</h2>

<table class="table table-striped mt-4">
    <thead>
        <tr>
            <th>Изображение</th>
            <th>Название</th>
            <th>Категория</th>
            <th>Цена</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($dishes as $dish): ?>
        <tr>
            <td><img src="../<?= htmlspecialchars($dish['imagePath']) ?>" width="50" class="img-thumbnail"></td>
            <td><?= htmlspecialchars($dish['nameOfDish']) ?></td>
            <td><?= htmlspecialchars($dish['categoryName']) ?></td>
            <td><?= $dish['price'] ?> руб.</td>
            <td>
                <a href="edit_dish.php?id=<?= $dish['id'] ?>" class="btn btn-sm btn-warning">
                    <i class="bi bi-pencil"></i>
                </a>
                <a href="delete_dish.php?id=<?= $dish['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Удалить блюдо?')">
                    <i class="bi bi-trash"></i>
                </a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<a href="add_dish.php" class="btn btn-primary">
    <i class="bi bi-plus-circle"></i> Добавить блюдо
</a>

<?php require_once '../includes/admin/footer.php'; ?>