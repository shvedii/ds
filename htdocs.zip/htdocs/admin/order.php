<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

redirectIfNotAdmin();

if (!isset($_GET['id'])) {
    header("Location: orders.php");
    exit();
}

$orderId = (int)$_GET['id'];

// Получение информации о заказе
$stmt = $conn->prepare("
    SELECT o.*, a.nameOfAccount as clientName, c.nameOfAccount as courierName 
    FROM Orders o 
    JOIN Account a ON o.clientId = a.id 
    LEFT JOIN Account c ON o.courierId = c.id 
    WHERE o.id = ?
");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header("Location: orders.php");
    exit();
}

// Получение блюд заказа
$stmt = $conn->prepare("
    SELECT od.*, d.nameOfDish, d.imagePath 
    FROM OrderOfDish od 
    JOIN Dish d ON od.dishId = d.id 
    WHERE od.orderId = ?
");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$dishes = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Получение списка курьеров
$couriers = $conn->query("
    SELECT id, nameOfAccount 
    FROM Account 
    WHERE roleId = (SELECT id FROM Role WHERE roleName = 'Courier')
")->fetch_all(MYSQLI_ASSOC);

// Обработка изменения статуса
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['status'])) {
    $newStatus = $_POST['status'];
    $courierId = isset($_POST['courier_id']) ? (int)$_POST['courier_id'] : null;
    
    $stmt = $conn->prepare("UPDATE Orders SET status = ?, courierId = ? WHERE id = ?");
    $stmt->bind_param("sii", $newStatus, $courierId, $orderId);
    
    if ($stmt->execute()) {
        header("Location: order.php?id=$orderId&updated=1");
        exit();
    }
}
?>

<?php include '../includes/admin/header.php'; ?>

<h1 class="text-center mb-4">Заказ #<?= $order['id'] ?></h1>

<?php if (isset($_GET['updated'])): ?>
    <div class="alert alert-success">Статус заказа обновлен</div>
<?php endif; ?>

<div class="row">
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Информация о заказе</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="order.php?id=<?= $order['id'] ?>">
                    <div class="mb-3">
                        <label class="form-label">Статус</label>
                        <select name="status" class="form-select">
                            <option value="В ожидании" <?= $order['status'] == 'В ожидании' ? 'selected' : '' ?>>В ожидании</option>
                            <option value="Принят" <?= $order['status'] == 'Принят' ? 'selected' : '' ?>>Принят</option>
                            <option value="Готов" <?= $order['status'] == 'Готов' ? 'selected' : '' ?>>Готов</option>
                            <option value="В пути" <?= $order['status'] == 'В пути' ? 'selected' : '' ?>>В пути</option>
                            <option value="Доставлен" <?= $order['status'] == 'Доставлен' ? 'selected' : '' ?>>Доставлен</option>
                            <option value="Отменен" <?= $order['status'] == 'Отменен' ? 'selected' : '' ?>>Отменен</option>
                        </select>
                    </div>
                    
                    <?php if ($order['status'] == 'Готов' || $order['status'] == 'В пути'): ?>
                        <div class="mb-3">
                            <label class="form-label">Курьер</label>
                            <select name="courier_id" class="form-select">
                                <option value="">-- Выберите курьера --</option>
                                <?php foreach ($couriers as $courier): ?>
                                    <option value="<?= $courier['id'] ?>" <?= $order['courierId'] == $courier['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($courier['nameOfAccount']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mb-3">
                        <label class="form-label">Клиент</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($order['clientName']) ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Адрес</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($order['address']) ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Телефон</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($order['phone']) ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Способ оплаты</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($order['paymentType']) ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Комментарии</label>
                        <textarea class="form-control" readonly><?= htmlspecialchars($order['comments']) ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Дата заказа</label>
                        <input type="text" class="form-control" value="<?= date('d.m.Y H:i', strtotime($order['createdAtOrder'])) ?>" readonly>
                    </div>
                    <button type="submit" class="btn btn-primary">Обновить статус</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Состав заказа</h5>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Блюдо</th>
                            <th>Количество</th>
                            <th>Цена</th>
                            <th>Итого</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dishes as $dish): ?>
                            <tr>
                                <td>
                                    <img src="../<?= htmlspecialchars($dish['imagePath']) ?>" width="50" height="50" class="me-2">
                                    <?= htmlspecialchars($dish['nameOfDish']) ?>
                                </td>
                                <td><?= $dish['quantity'] ?></td>
                                <td><?= $dish['priceDish'] ?> руб.</td>
                                <td><?= $dish['priceDish'] * $dish['quantity'] ?> руб.</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-end"><strong>Итого:</strong></td>
                            <td><strong><?= $order['totalPrice'] ?> руб.</strong></td>
                        </tr>
                        <?php if ($order['usedBonuses']): ?>
                            <tr>
                                <td colspan="3" class="text-end"><strong>Использовано бонусов:</strong></td>
                                <td><strong><?= array_reduce($dishes, function($sum, $dish) { return $sum + ($dish['priceDish'] * $dish['quantity']); }, 0) - $order['totalPrice'] ?> руб.</strong></td>
                            </tr>
                        <?php endif; ?>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="text-center">
    <a href="orders.php" class="btn btn-secondary">Вернуться к списку заказов</a>
</div>

<?php include '../includes/admin/footer.php'; ?>