<?php
require_once '../includes/admin/header.php';

if (!isset($_GET['id'])) {
    header("Location: dishes.php");
    exit();
}

$dishId = (int)$_GET['id'];
$categories = $conn->query("SELECT * FROM Category")->fetch_all(MYSQLI_ASSOC);

// Получение данных блюда
$stmt = $conn->prepare("SELECT * FROM Dish WHERE id = ?");
$stmt->bind_param("i", $dishId);
$stmt->execute();
$dish = $stmt->get_result()->fetch_assoc();

if (!$dish) {
    header("Location: dishes.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = (int)$_POST['price'];
    $categoryId = (int)$_POST['category_id'];
    $imagePath = $dish['imagePath'];
    
    // Обработка загрузки изображения
    if (!empty($_FILES['image']['name'])) {
        $uploadDir = '../assets/images/dishes/';
        $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $extension;
        $destination = $uploadDir . $filename;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
            // Удаляем старое изображение, если оно не дефолтное
            if ($dish['imagePath'] != 'assets/images/dishes/default.jpg') {
                @unlink('../' . $dish['imagePath']);
            }
            $imagePath = 'assets/images/dishes/' . $filename;
        }
    }
    
    $stmt = $conn->prepare("UPDATE Dish SET nameOfDish = ?, descriptionOfDishes = ?, price = ?, categoryId = ?, imagePath = ? WHERE id = ?");
    $stmt->bind_param("ssiisi", $name, $description, $price, $categoryId, $imagePath, $dishId);
    
    if ($stmt->execute()) {
        header("Location: dishes.php?success=Блюдо успешно обновлено");
        exit();
    }
}
?>

<h2><i class="bi bi-pencil"></i> Редактирование блюда</h2>

<form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
        <label class="form-label">Название</label>
        <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($dish['nameOfDish']) ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Описание</label>
        <textarea class="form-control" name="description" rows="3" required><?= htmlspecialchars($dish['descriptionOfDishes']) ?></textarea>
    </div>
    <div class="mb-3">
        <label class="form-label">Цена (руб.)</label>
        <input type="number" class="form-control" name="price" value="<?= $dish['price'] ?>" min="1" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Категория</label>
        <select class="form-select" name="category_id" required>
            <?php foreach ($categories as $category): ?>
                <option value="<?= $category['id'] ?>" <?= $category['id'] == $dish['categoryId'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($category['categoryName']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Изображение</label>
        <input type="file" class="form-control" name="image">
        <div class="mt-2">
            <small>Текущее изображение:</small><br>
            <img src="../<?= htmlspecialchars($dish['imagePath']) ?>" width="100" class="img-thumbnail mt-2">
        </div>
    </div>
    <button type="submit" class="btn btn-primary">Сохранить</button>
    <a href="dishes.php" class="btn btn-secondary">Отмена</a>
</form>

<?php require_once '../includes/admin/footer.php'; ?>