<?php
require_once '../includes/admin/header.php';

$roles = $conn->query("SELECT * FROM Role")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $roleId = (int)$_POST['role_id'];
    $bonuses = (int)$_POST['bonuses'];
    
    if (empty($name) || empty($email) || empty($password)) {
        $error = "Все поля обязательны для заполнения";
    } else {
        $hashedPassword = hash('sha256', $password);
        $stmt = $conn->prepare("INSERT INTO Account (nameOfAccount, email, password, roleId, bonuses) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssii", $name, $email, $hashedPassword, $roleId, $bonuses);
        
        if ($stmt->execute()) {
            header("Location: users.php?success=Пользователь успешно добавлен");
            exit();
        } else {
            $error = "Ошибка при добавлении пользователя: " . $conn->error;
        }
    }
}
?>

<h2><i class="bi bi-person-plus"></i> Добавить пользователя</h2>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST">
    <div class="mb-3">
        <label class="form-label">Имя</label>
        <input type="text" class="form-control" name="name" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" name="email" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Пароль</label>
        <input type="password" class="form-control" name="password" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Роль</label>
        <select class="form-select" name="role_id" required>
            <?php foreach ($roles as $role): ?>
                <option value="<?= $role['id'] ?>"><?= htmlspecialchars($role['roleName']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Бонусы</label>
        <input type="number" class="form-control" name="bonuses" value="0" min="0">
    </div>
    <button type="submit" class="btn btn-primary">Добавить</button>
    <a href="users.php" class="btn btn-secondary">Отмена</a>
</form>

<?php require_once '../includes/admin/footer.php'; ?>