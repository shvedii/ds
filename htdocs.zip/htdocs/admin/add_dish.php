<?php
require_once '../includes/admin/header.php';

$categories = $conn->query("SELECT * FROM Category")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = (int)$_POST['price'];
    $categoryId = (int)$_POST['category_id'];
    $imagePath = 'assets/images/dishes/default.jpg';
    
    // Обработка загрузки изображения
    if (!empty($_FILES['image']['name'])) {
        $uploadDir = '../assets/images/dishes/';
        $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $extension;
        $destination = $uploadDir . $filename;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
            $imagePath = 'assets/images/dishes/' . $filename;
        }
    }
    
    $stmt = $conn->prepare("INSERT INTO Dish (nameOfDish, descriptionOfDishes, price, categoryId, imagePath) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiis", $name, $description, $price, $categoryId, $imagePath);
    
    if ($stmt->execute()) {
        header("Location: dishes.php?success=Блюдо успешно добавлено");
        exit();
    }
}
?>

<h2><i class="bi bi-plus-circle"></i> Добавить блюдо</h2>

<form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
        <label class="form-label">Название</label>
        <input type="text" class="form-control" name="name" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Описание</label>
        <textarea class="form-control" name="description" rows="3" required></textarea>
    </div>
    <div class="mb-3">
        <label class="form-label">Цена (руб.)</label>
        <input type="number" class="form-control" name="price" min="1" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Категория</label>
        <select class="form-select" name="category_id" required>
            <?php foreach ($categories as $category): ?>
                <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['categoryName']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Изображение</label>
        <input type="file" class="form-control" name="image">
    </div>
    <button type="submit" class="btn btn-primary">Добавить</button>
    <a href="dishes.php" class="btn btn-secondary">Отмена</a>
</form>

<?php require_once '../includes/admin/footer.php'; ?>