<?php
require_once '../includes/admin/header.php';

if (!isset($_GET['id'])) {
    header("Location: categories.php");
    exit();
}

$categoryId = (int)$_GET['id'];

// Получение данных категории
$stmt = $conn->prepare("SELECT * FROM Category WHERE id = ?");
$stmt->bind_param("i", $categoryId);
$stmt->execute();
$category = $stmt->get_result()->fetch_assoc();

if (!$category) {
    header("Location: categories.php");
    exit();
}

$breadcrumbs = [
    ['title' => 'Категории меню', 'link' => 'categories.php'],
    ['title' => 'Редактирование категории', 'link' => '']
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $categoryName = trim($_POST['category_name']);
    
    if (empty($categoryName)) {
        $error = "Название категории обязательно для заполнения";
    } else {
        // Проверка на существование категории
        $stmt = $conn->prepare("SELECT id FROM Category WHERE categoryName = ? AND id != ?");
        $stmt->bind_param("si", $categoryName, $categoryId);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            $error = "Категория с таким названием уже существует";
        } else {
            $stmt = $conn->prepare("UPDATE Category SET categoryName = ? WHERE id = ?");
            $stmt->bind_param("si", $categoryName, $categoryId);
            
            if ($stmt->execute()) {
                header("Location: categories.php?success=Категория успешно обновлена");
                exit();
            } else {
                $error = "Ошибка при обновлении категории: " . $conn->error;
            }
        }
    }
}
?>

<div class="card">
    <div class="card-header">
        <h4><i class="bi bi-pencil"></i> Редактирование категории</h4>
    </div>
    <div class="card-body">
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label for="category_name" class="form-label">Название категории</label>
                <input type="text" class="form-control" id="category_name" name="category_name" 
                       value="<?= htmlspecialchars($category['categoryName']) ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Сохранить</button>
            <a href="categories.php" class="btn btn-secondary">Отмена</a>
        </form>
    </div>
</div>

<?php require_once '../includes/admin/footer.php'; ?>