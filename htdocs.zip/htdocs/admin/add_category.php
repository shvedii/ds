<?php
require_once '../includes/admin/header.php';

$breadcrumbs = [
    ['title' => 'Категории меню', 'link' => 'categories.php'],
    ['title' => 'Добавление категории', 'link' => '']
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $categoryName = trim($_POST['category_name']);
    
    if (empty($categoryName)) {
        $error = "Название категории обязательно для заполнения";
    } else {
        // Проверка на существование категории
        $stmt = $conn->prepare("SELECT id FROM Category WHERE categoryName = ?");
        $stmt->bind_param("s", $categoryName);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            $error = "Категория с таким названием уже существует";
        } else {
            $stmt = $conn->prepare("INSERT INTO Category (categoryName) VALUES (?)");
            $stmt->bind_param("s", $categoryName);
            
            if ($stmt->execute()) {
                header("Location: categories.php?success=Категория успешно добавлена");
                exit();
            } else {
                $error = "Ошибка при добавлении категории: " . $conn->error;
            }
        }
    }
}
?>

<div class="card">
    <div class="card-header">
        <h4><i class="bi bi-plus-circle"></i> Добавление новой категории</h4>
    </div>
    <div class="card-body">
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label for="category_name" class="form-label">Название категории</label>
                <input type="text" class="form-control" id="category_name" name="category_name" required>
            </div>
            <button type="submit" class="btn btn-primary">Добавить</button>
            <a href="categories.php" class="btn btn-secondary">Отмена</a>
        </form>
    </div>
</div>

<?php require_once '../includes/admin/footer.php'; ?>