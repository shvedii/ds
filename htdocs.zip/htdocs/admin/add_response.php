<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

redirectIfNotAdmin();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['review_id'])) {
    $reviewId = (int)$_POST['review_id'];
    $responseText = trim($_POST['response']);
    
    if (!empty($responseText)) {
        $stmt = $conn->prepare("INSERT INTO Response (responseText, createdAtResponse, adminId, reviewId) VALUES (?, NOW(), ?, ?)");
        $stmt->bind_param("sii", $responseText, $_SESSION['user_id'], $reviewId);
        
        if ($stmt->execute()) {
            header("Location: reviews_admin.php?success=Ответ добавлен");
            exit();
        }
    }
}

header("Location: reviews_admin.php?error=Ошибка при добавлении ответа");
?>