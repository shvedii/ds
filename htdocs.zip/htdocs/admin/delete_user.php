<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

redirectIfNotAdmin();

if (!isset($_GET['id'])) {
    header("Location: users.php");
    exit();
}

$userId = (int)$_GET['id'];

// Проверяем, что пользователь не удаляет себя
if ($userId == $_SESSION['user_id']) {
    header("Location: users.php?error=Нельзя удалить самого себя");
    exit();
}

$stmt = $conn->prepare("DELETE FROM Account WHERE id = ?");
$stmt->bind_param("i", $userId);

if ($stmt->execute()) {
    header("Location: users.php?success=Пользователь успешно удален");
} else {
    header("Location: users.php?error=Ошибка при удалении пользователя");
}
?>