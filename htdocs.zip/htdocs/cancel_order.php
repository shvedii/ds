<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: orders.php");
    exit();
}

$orderId = (int)$_GET['id'];

// Проверяем, что заказ принадлежит пользователю и его можно отменить
$stmt = $conn->prepare("SELECT id, status, totalPrice, usedBonuses, clientId FROM Orders WHERE id = ? AND clientId = ? AND status = 'В ожидании'");
$stmt->bind_param("ii", $orderId, $_SESSION['user_id']);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header("Location: orders.php");
    exit();
}

// Возвращаем бонусы, если они были использованы
if ($order['usedBonuses']) {
    // Получаем сумму использованных бонусов
    $stmt = $conn->prepare("
        SELECT SUM(od.priceDish * od.quantity) - ? as usedBonuses 
        FROM OrderOfDish od 
        WHERE od.orderId = ?
    ");
    $stmt->bind_param("ii", $order['totalPrice'], $orderId);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $usedBonuses = $result['usedBonuses'];
    
    // Возвращаем бонусы
    $stmt = $conn->prepare("UPDATE Account SET bonuses = bonuses + ? WHERE id = ?");
    $stmt->bind_param("ii", $usedBonuses, $_SESSION['user_id']);
    $stmt->execute();
}

// Отменяем заказ
$stmt = $conn->prepare("UPDATE Orders SET status = 'Отменен' WHERE id = ?");
$stmt->bind_param("i", $orderId);
$stmt->execute();

header("Location: orders.php?canceled=1");
exit();
?>