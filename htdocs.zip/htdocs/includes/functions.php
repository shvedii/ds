<?php
// includes/functions.php
require_once 'config.php';

function getCategories() {
    global $conn;
    $sql = "SELECT * FROM Category";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

function getDishesByCategory($categoryId) {
    global $conn;
    $sql = "SELECT * FROM Dish WHERE categoryId = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $categoryId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

function getDishById($dishId) {
    global $conn;
    $sql = "SELECT * FROM Dish WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $dishId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function getUserById($userId) {
    global $conn;
    $sql = "SELECT * FROM Account WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function getReviews() {
    global $conn;
    $sql = "SELECT r.*, a.nameOfAccount FROM Review r JOIN Account a ON r.clientId = a.id ORDER BY r.createdAtReview DESC";
    $result = $conn->query($sql);
    return $result->fetch_all(MYSQLI_ASSOC);
}

function getResponsesForReview($reviewId) {
    global $conn;
    $sql = "SELECT * FROM Response WHERE reviewId = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $reviewId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}
?>

