<?php
// includes/auth.php
if (!isset($_SESSION)) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] == 'Admin';
}

function isCourier() {
    return isset($_SESSION['role']) && $_SESSION['role'] == 'Courier';
}

function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit();
    }
}

function redirectIfNotAdmin() {
    if (!isAdmin()) {
        header("Location: ../index.php");
        exit();
    }
}

function redirectIfNotCourier() {
    if (!isCourier()) {
        header("Location: ../index.php");
        exit();
    }
}
?>