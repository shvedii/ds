</div>
    <footer class="bg-dark text-white mt-5 py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>AMOUR</h5>
                    <p>Доставка изысканных блюд</p>
                </div>
                <div class="col-md-4">
                    <h5>Контакты</h5>
                    <p>Телефон: +7 (123) 456-7890</p>
                </div>
                <div class="col-md-4">
                    <h5>Часы работы</h5>
                    <p>Ежедневно с 10:00 до 23:00</p>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>