<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: orders.php");
    exit();
}

$orderId = (int)$_GET['id'];

// Получение информации о заказе
$stmt = $conn->prepare("
    SELECT o.*, a.nameOfAccount as courierName 
    FROM Orders o 
    LEFT JOIN Account a ON o.courierId = a.id 
    WHERE o.id = ? AND o.clientId = ?
");
$stmt->bind_param("ii", $orderId, $_SESSION['user_id']);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header("Location: orders.php");
    exit();
}

// Получение блюд заказа
$stmt = $conn->prepare("
    SELECT od.*, d.nameOfDish, d.imagePath 
    FROM OrderOfDish od 
    JOIN Dish d ON od.dishId = d.id 
    WHERE od.orderId = ?
");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$dishes = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<?php include 'includes/header.php'; ?>

<h1 class="text-center mb-4">Заказ #<?= $order['id'] ?></h1>

<div class="row">
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Информация о заказе</h5>
            </div>
            <div class="card-body">
                <p><strong>Дата заказа:</strong> <?= date('d.m.Y H:i', strtotime($order['createdAtOrder'])) ?></p>
                <p><strong>Статус:</strong> 
                    <span class="badge 
                        <?= $order['status'] == 'Доставлен' ? 'bg-success' : '' ?>
                        <?= $order['status'] == 'Отменен' ? 'bg-danger' : '' ?>
                        <?= in_array($order['status'], ['В ожидании', 'Принят', 'Готов', 'В пути']) ? 'bg-warning' : '' ?>
                    ">
                        <?= $order['status'] ?>
                    </span>
                </p>
                <p><strong>Адрес доставки:</strong> <?= htmlspecialchars($order['address']) ?></p>
                <p><strong>Телефон:</strong> <?= htmlspecialchars($order['phone']) ?></p>
                <p><strong>Способ оплаты:</strong> <?= htmlspecialchars($order['paymentType']) ?></p>
                <p><strong>Комментарии:</strong> <?= htmlspecialchars($order['comments']) ?></p>
                <?php if ($order['courierName']): ?>
                    <p><strong>Курьер:</strong> <?= htmlspecialchars($order['courierName']) ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Состав заказа</h5>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Блюдо</th>
                            <th>Количество</th>
                            <th>Цена</th>
                            <th>Итого</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dishes as $dish): ?>
                            <tr>
                                <td>
                                    <img src="<?= htmlspecialchars($dish['imagePath']) ?>" width="50" height="50" class="me-2">
                                    <?= htmlspecialchars($dish['nameOfDish']) ?>
                                </td>
                                <td><?= $dish['quantity'] ?></td>
                                <td><?= $dish['priceDish'] ?> руб.</td>
                                <td><?= $dish['priceDish'] * $dish['quantity'] ?> руб.</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-end"><strong>Итого:</strong></td>
                            <td><strong><?= $order['totalPrice'] ?> руб.</strong></td>
                        </tr>
                        <?php if ($order['usedBonuses']): ?>
                            <tr>
                                <td colspan="3" class="text-end"><strong>Использовано бонусов:</strong></td>
                                <td><strong><?= $order['totalPrice'] - array_reduce($dishes, function($sum, $dish) { return $sum + ($dish['priceDish'] * $dish['quantity']); }, 0) ?> руб.</strong></td>
                            </tr>
                        <?php endif; ?>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="text-center">
    <a href="orders.php" class="btn btn-primary">Вернуться к списку заказов</a>
</div>

<?php include 'includes/footer.php'; ?>