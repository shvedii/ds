CREATE TABLE Role (
    id INT PRIMARY KEY AUTO_INCREMENT,
    roleName ENUM('User', 'Admin', 'Courier') NOT NULL
);

CREATE TABLE Account (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(50) UNIQUE NOT NULL,
    nameOfAccount VARCHAR(50) NOT NULL UNIQUE,
    password CHAR(64) NOT NULL,
    bonuses INT DEFAULT 0 NOT NULL,
    roleId INT NOT NULL,
    FOREIGN KEY (roleId) REFERENCES Role(id)
);

CREATE TABLE Category (
    id INT PRIMARY KEY AUTO_INCREMENT,
    categoryName ENUM('Закуски', 'Салаты', 'Супы', 'Горячие блюда', 'Напитки', 'Алкогольные напитки') NOT NULL UNIQUE
);

CREATE TABLE Dish (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nameOfDish VARCHAR(50) NOT NULL UNIQUE,
    descriptionOfDishes VARCHAR(255) NOT NULL,
    price INT NOT NULL,
    categoryId INT NOT NULL,
    imagePath VARCHAR(255) NOT NULL,
    FOREIGN KEY (categoryId) REFERENCES Category(id)
);

CREATE TABLE Orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    address VARCHAR(100) NOT NULL,
    phone VARCHAR(12) NOT NULL,
    paymentType ENUM('Карта', 'Электронный кошелек', 'СПБ') NOT NULL,
    comments VARCHAR(100) NOT NULL,
    status ENUM('В ожидании', 'Принят', 'Готов', 'В пути', 'Доставлен', 'Отменен') NOT NULL DEFAULT 'В ожидании',
    createdAtOrder TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    totalPrice INT NOT NULL,
    usedBonuses BOOLEAN DEFAULT FALSE NOT NULL,
    clientId INT NOT NULL,
    courierId INT DEFAULT NULL, 
    FOREIGN KEY (clientId) REFERENCES Account(id),
    FOREIGN KEY (courierId) REFERENCES Account(id)
);

CREATE TABLE OrderOfDish (
    id INT PRIMARY KEY AUTO_INCREMENT,
    quantity INT NOT NULL,
    priceDish INT NOT NULL,
    dishId INT NOT NULL,
    orderId INT NOT NULL,
    FOREIGN KEY (dishId) REFERENCES Dish(id),
    FOREIGN KEY (orderId) REFERENCES Orders(id)
);

CREATE TABLE Review (
    id INT PRIMARY KEY AUTO_INCREMENT,
    textReview VARCHAR(100) NOT NULL,
    createdAtReview DATE NOT NULL,
    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    clientId INT NOT NULL,
    FOREIGN KEY (clientId) REFERENCES Account(id)
);

CREATE TABLE Response (
    id INT PRIMARY KEY AUTO_INCREMENT,
    responseText VARCHAR(255) NOT NULL,
    createdAtResponse DATE NOT NULL,
    adminId INT NOT NULL,
    reviewId INT NOT NULL,
    FOREIGN KEY (adminId) REFERENCES Account(id),
    FOREIGN KEY (reviewId) REFERENCES Review(id)
);

